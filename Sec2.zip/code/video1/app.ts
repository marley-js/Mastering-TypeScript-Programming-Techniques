// [0, 1, 2].map(function(num) {
//   return num;
// });
[0, 1, 2].map((num) => num);
