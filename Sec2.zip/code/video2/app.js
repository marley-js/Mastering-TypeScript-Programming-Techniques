[0, 1, 2].map(function (num) { return num; });
//# sourceMappingURL=app.js.map