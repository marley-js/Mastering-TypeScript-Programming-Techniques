[0, 1, 2].map((num) => num);
